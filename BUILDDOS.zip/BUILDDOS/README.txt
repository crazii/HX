This is a ready-to-use toolchain that make HDPMI32i.exe under DOS.

**SETUP/UPGRADE (on windows)

the toolchians runs under HX env, so HXRT & HXDEV is needed.
this package already contains pre-setup ones, skip the SETUP part goto the SETUP ON DOS if you want to build directly.

HXRT
Download from: https://github.com/Baron-von-Riedesel/HX/releases, and put it under current folder, i.e. .\HXRT220
the curent folder contains a pre-downloaded HXRT220, if you want to upgrade, delete the old folder and place the new one.

HXDEV
Download from: https://github.com/Baron-von-Riedesel/HX/releases, and put it under current folder, i.e. .\HXDEV219
the curent folder contains a pre-downloaded HXDEV219, if you want to upgrade, delete the old folder and place the new one.

JWasm_win32
Download from: https://github.com/Baron-von-Riedesel/JWasm/releases, (win32 build), and unpack to the current folder, i.e. JWasm_win32.
The win32 build cannot run directly under dos, but after PESTUB, it can run under HX env in DOS. 
Run:
$(HXDEV)\bin\pestub $(JWasm_win32)\jwasm.exe

where HXDEV is the hxdev folder in this package, i.e. .\HXDEV219
This folder already contains a pre-stubbed binary. Do the above if you want uprade JWasm.


JWlink_win32
Download from: https://github.com/Baron-von-Riedesel/jwlink/releases, (win32 build), and unpack to the current folder. Then run
$(HXDEV)\bin\pestub $(JWlink_win32)\jwlink.exe
$(HXDEV)\bin\pestub $(JWlink_win32)\jwlib.exe

where HXDEV is the hxdev folder in this package.
This folder already contains pre-stubbed binaries. Do the above if you want uprade JWlink.

**SETUP ON DOS

Put the latest HX source from git (https://github.com/crazii/HX), to the DOS disk, i.e. C:\HX
Put the unpacked folder of this package under DOS, i.e. C:\BUILDDOS
set up path evn var, those paths contain HX(RT) env, nmake, jwlink, jwlib, and HXDEV bins:

set BUILDDOS=C:\BUILDDOS
set path=%BUILDDOS%;%BUILDDOS%\HXRT220\bin;%BUILDDOS%\JWasm_v216_win32;%BUILDDOS%\JWlink_v19b16_win32;%BUILDDOS%\HXDEV219\BIN;%path%
set HXSRC=C:\HX

set the path ONLY once before build, or put it in the autoexec.bat

**MAKE

run make(.bat) to build
run make clean to clean
the built binary is located at %HX%\Src\HDPMI\IOPL032\HDPMI32i.exe

**BUILD ON WINDOWS
the same toolchains are used to bild HDPMI32i under windows, except that you need a win32 NMAKE from MS (i.e. visual studio), or from OpenWatcom.
and skip the stubbing part of the JWasm, JWlink.